package vehicle;

public class Car extends Vehicle {

    private static final double FUEL_PER_SUMMER = 0.9;

    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);
        super.setFuelConsumption(getFuelConsumption() + FUEL_PER_SUMMER);
    }

}
