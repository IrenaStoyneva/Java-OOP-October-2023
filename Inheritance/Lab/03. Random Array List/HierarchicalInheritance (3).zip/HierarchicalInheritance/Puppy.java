package HierarchicalInheritance;

public class Puppy extends Animal{

    public void weep(){
        System.out.println("weeping...");
    }
}
