package person;

public interface Identifiable {

    String getId();

}
