package HierarchicalInheritance;

public class Puppy {

    public void weep(){
        System.out.println("weeping...");
    }
}
